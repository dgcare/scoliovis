export default function landmarksToCoordinates(landmarks: number[]) {}
