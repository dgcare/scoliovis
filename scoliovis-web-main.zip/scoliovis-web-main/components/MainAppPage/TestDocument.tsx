import { BlobProvider, Document, Page, Text } from "@react-pdf/renderer";

// const MyDoc = (
//   <Document>
//     <Page>
//       <Text>Carlo Taleon is Cool</Text>
//     </Page>
//   </Document>
// );
const MyDoc = (
  <Document>
    <Page>
      <Text>Carlo Anthony Bum</Text>
    </Page>
  </Document>
);

export default MyDoc;
